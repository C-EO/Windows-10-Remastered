from qtpy import uic

uic.compileUiDir("ui")
